@extends('layouts.app')

@section('content')
    profile settings
@endsection
