@extends('layouts.app')

@section('content')
    settings
@endsection
