@extends('layouts.app')

@section('content')
    <div class="d-flex justify-content-start">
        <div class="card">
            <div class="card-header">
                My automation website
            </div>
            <div class="card-body">
                <h2>Thank you message</h2>
                <blockquote class="blockquote">
                    <p>
                        Lorem ipsum dolor sit amet consectetur
                        adipisicing elit. Nulla ex eveniet sapiente, ad non neque alias quos
                        beatae molestiae corrupti doloribus tempore harum earum,
                        pariatur perspiciatis aliquam quaerat, voluptates deleniti.
                    </p>
                </blockquote>
            </div>
        </div>
    </div>
@endsection
