<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-start">
        <div class="card">
            <div class="card-header">
                My automation website
            </div>
            <div class="card-body">
                <h2>Thank you message</h2>
                <blockquote class="blockquote">
                    <p>
                        Lorem ipsum dolor sit amet consectetur
                        adipisicing elit. Nulla ex eveniet sapiente, ad non neque alias quos
                        beatae molestiae corrupti doloribus tempore harum earum,
                        pariatur perspiciatis aliquam quaerat, voluptates deleniti.
                    </p>
                </blockquote>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bifang\livebusiness\resources\views/pages/index.blade.php ENDPATH**/ ?>