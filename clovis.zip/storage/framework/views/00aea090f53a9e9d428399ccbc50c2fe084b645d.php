<?php $__env->startSection('content'); ?>
<div class="d-flex w-100 justify-content-between">
    <h5 class="mb-1">Article</h5>
    <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-primary">Add</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bifang\livebusiness\resources\views/articles/index.blade.php ENDPATH**/ ?>