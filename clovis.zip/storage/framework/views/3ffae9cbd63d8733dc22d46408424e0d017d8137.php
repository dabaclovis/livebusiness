<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header bg-secondary text-white">
            Create Article
        </div>
        <div class="card-body">
            <?php echo $__env->make('partials.createform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bifang\livebusiness\resources\views/articles/create.blade.php ENDPATH**/ ?>