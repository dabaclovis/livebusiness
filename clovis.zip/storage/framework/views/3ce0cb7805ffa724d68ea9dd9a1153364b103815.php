<?php echo Form::open(); ?>

   <div class="form-group mb-2">
        <?php echo Form::label('title', 'Title', ['class' => 'fs-5']); ?>

        <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

   </div>
   <div class="form-group mb-2">
    <?php echo Form::label('body', 'Content', ['class' => 'fs-5']); ?>

        <?php echo Form::textarea('body', null, ['class' => 'form-control']); ?>

   </div>
   <div class="form-group mb-2">

        <?php echo Form::file('image', ['class' => 'form-control']); ?>

   </div>
   <div class="form-group mb-2">
    <div class="d-flex justify-content-end">
        <?php echo Form::submit('Submit', ['class' => 'btn btn-primary btn-md']); ?>

    </div>
   </div>
<?php echo Form::close(); ?>

<?php /**PATH D:\xampp\htdocs\bifang\livebusiness\resources\views/partials/createform.blade.php ENDPATH**/ ?>